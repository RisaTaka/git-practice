Rails.application.routes.draw do
  root :to => 'books#index'
  get 'info/index'
  get 'home/index'
  resources :books
  get 'top' => 'homes#top'
  post 'books' => 'books#create'
  get 'books' => 'books#index'
  get 'books/:id' => 'books#show'
  get 'books/:id/edit' => 'books#edit'
  patch 'books/:id' => 'books#update'
  delete 'books/:id' => 'books#destroy'

end
