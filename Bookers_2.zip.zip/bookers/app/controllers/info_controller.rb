class InfoController < ApplicationController
  def index
  end
end
