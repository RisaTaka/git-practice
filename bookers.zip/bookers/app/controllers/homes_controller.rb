class HomesController < ApplicationController

  def top
    @books = Book.all
  end

  def index

  end

  def show
  end

  def new
  end

  def edit
  end
end
